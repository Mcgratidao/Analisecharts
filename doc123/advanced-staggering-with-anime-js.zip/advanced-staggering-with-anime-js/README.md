# Advanced staggering with anime.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/juliangarnier/pen/MZXQNV](https://codepen.io/juliangarnier/pen/MZXQNV).

An animation that demonstrate the new anime.js grid staggering feature. Made for https://animejs.com.